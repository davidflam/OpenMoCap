#ifndef _IDISPIDS_H
#define _IDISPIDS_H
#if __GNUC__ >=3
#pragma GCC system_header
#endif

#define DISPID_AMBIENT_OFFLINEIFNOTCONNECTED (-5501)
#define DISPID_AMBIENT_SILENT (-5502)

#endif
